changes:

i worked off of a copy i had of the site from 3/10

added in dashboard.html
{% if current_user.id <= 1000 %}

<a href="{{ url_for('confirm_status') }}">
<button class="btn-ru" style="margin-top: -25px;">Change Confirmation Status</button>
</a>

{% endif %}

added in manage.html
{% if current_user.is_mentor == True %}

<div class="check-wrapper">
<div class="squaredThree">
<input type="checkbox" value="None" id="squaredThree" name="check" checked="true"/>
<label for="squaredThree"></label>
</div>
<p class="checkbox">Confirmed as Mentor.</p>
</div>

{% elif current_user.is_mentor == False %}

<div class="check-wrapper">
<div class="squaredThree">
<input type="checkbox" value="None" id="squaredThree" name="check"/>
<label for="squaredThree"></label>
</div>
<p class="checkbox">Sign me up as a Mentor.</p>
</div>

{% end if %}

added sponsors in index.html